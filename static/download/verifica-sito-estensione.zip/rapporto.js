// Rapporto completo dentro l'estensione.
//
// La differenza con lo strumento sul web non è l'aspetto: è da dove partono le
// richieste. Qui le pagine le scarica il tuo browser, con il tuo indirizzo IP e
// la tua sessione. Quindi funziona sui siti che rifiutano le richieste
// provenienti dai datacenter, e sulle aree riservate a cui hai già accesso.
import { analizzaPagina } from './analisi.js';
import { CONTROLLI } from './controlli.js';

const MAX_URL = 200;
const IN_PARALLELO = 6;
const SITEMAP_PROBABILI = [
  '/sitemap.xml',
  '/sitemap_index.xml',   // Yoast, Rank Math, All in One SEO
  '/wp-sitemap.xml',      // WordPress dal 5.5 in poi
  '/sitemap-index.xml',
  '/sitemap/sitemap-index.xml',
  '/sitemap1.xml',
  '/page-sitemap.xml',
  '/post-sitemap.xml',
];

const API_VELOCITA = 'https://puntowebferrara.com/api/lighthouse?url=';

const T = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const livello = (q) => q == null ? 'grigio'
  : q >= 0.999 ? 'ok' : q >= 0.95 ? 'ok' : q >= 0.75 ? 'giallo' : q >= 0.35 ? 'arancio' : 'rosso';

const SEGNI = { ok: '✓ ', giallo: '! ', arancio: '▲ ', rosso: '✕ ', grigio: '– ' };

// ---------------------------------------------------------------- crawler
async function prendi(url, limite) {
  try {
    const r = await fetch(url, { redirect: 'follow', credentials: 'omit' });
    if (!r.ok) return { ok: false, stato: r.status };
    let t = await r.text();
    if (limite && t.length > limite) t = t.slice(0, limite);
    return { ok: true, stato: r.status, testo: t, intestazioni: r.headers };
  } catch (e) {
    return { ok: false, errore: String(e.message || e) };
  }
}

const BOT = [
  ['GPTBot', 'ChatGPT — addestramento e ricerca', 1], ['OAI-SearchBot', 'ChatGPT — ricerca', 1],
  ['ChatGPT-User', 'ChatGPT — navigazione su richiesta', 1], ['ClaudeBot', 'Claude', 1],
  ['Claude-User', 'Claude — navigazione su richiesta', 1], ['PerplexityBot', 'Perplexity', 1],
  ['Google-Extended', 'Google Gemini e AI Overviews', 2], ['GoogleOther', 'Google — usi sperimentali', 2],
  ['Applebot-Extended', 'Apple Intelligence', 2], ['Amazonbot', 'Amazon', 2],
  ['Bingbot', 'Bing e Copilot', 2], ['CCBot', 'Common Crawl', 2],
  ['Bytespider', 'ByteDance', 2], ['cohere-ai', 'Cohere', 2],
];

function leggiRobots(testo) {
  const blocchi = [];
  let corrente = null;
  for (let riga of (testo || '').split(/\r?\n/)) {
    riga = riga.replace(/#.*$/, '').trim();
    if (!riga) continue;
    const i = riga.indexOf(':');
    if (i < 0) continue;
    const campo = riga.slice(0, i).trim().toLowerCase();
    const valore = riga.slice(i + 1).trim();
    if (campo === 'user-agent') {
      if (!corrente || corrente.regole.length) { corrente = { agenti: [], regole: [] }; blocchi.push(corrente); }
      corrente.agenti.push(valore.toLowerCase());
    } else if (corrente && (campo === 'allow' || campo === 'disallow')) {
      corrente.regole.push({ tipo: campo, percorso: valore });
    }
  }
  return (nome) => {
    const n = nome.toLowerCase();
    let b = blocchi.find(x => x.agenti.includes(n)) || blocchi.find(x => x.agenti.includes('*'));
    if (!b) return { ammesso: true, esplicito: false };
    const vieta = b.regole.some(r => r.tipo === 'disallow' && (r.percorso === '/' || r.percorso === ''));
    const permette = b.regole.some(r => r.tipo === 'allow' && r.percorso === '/');
    return { ammesso: permette || !vieta, esplicito: true };
  };
}

async function scopri(origine, avanza) {
  avanza('Leggo robots.txt e sitemap…', 0.05);
  const robots = await prendi(origine + '/robots.txt', 60000);
  const decidi = leggiRobots(robots.ok ? robots.testo : '');

  const dichiarate = robots.ok
    ? [...robots.testo.matchAll(/^\s*sitemap\s*:\s*(\S+)/gim)].map(m => m[1])
    : [];
  const coda = dichiarate.length
    ? dichiarate.slice(0, 10)
    : SITEMAP_PROBABILI.map(x => origine + x);
  const pagine = [];
  const viste = new Set();
  let letti = 0;

  while (coda.length && pagine.length < MAX_URL && letti < 20) {
    const doc = await prendi(coda.shift(), 900000);
    letti++;
    if (!doc.ok) continue;
    const loc = [...doc.testo.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/g)].map(m => m[1].trim());
    const figlie = /<sitemapindex/i.test(doc.testo);
    for (const u of loc) {
      if (figlie) { if (coda.length < 12) coda.push(u); continue; }
      if (!viste.has(u) && pagine.length < MAX_URL) { viste.add(u); pagine.push(u); }
    }
  }
  if (!pagine.length) pagine.push(origine + '/');

  avanza('Controllo come risponde a un indirizzo inesistente…', 0.1);
  let statoFinto = null;
  try {
    const r = await fetch(origine + '/pagina-inesistente-verifica-' + Date.now() + '/', { redirect: 'follow' });
    statoFinto = r.status;
  } catch (e) { /* non blocca */ }

  const llms = await prendi(origine + '/llms.txt', 40000);

  return {
    pagine, decidi,
    sitemapTrovate: dichiarate.length || (pagine.length > 1 ? 1 : 0),
    llmsPresente: llms.ok,
    statoFinto,
    intestazioniHome: null,
  };
}

// ---------------------------------------------------------------- punteggio
function calcola(pagine, scoperta) {
  const perPagina = {};
  const chiavi = Object.keys(pagine[0].flag);
  for (const k of chiavi) {
    const n = pagine.filter(p => p.flag[k]).length;
    perPagina[k] = { quota: n / pagine.length, n, tot: pagine.length };
  }

  const primari = BOT.filter(b => b[2] === 1).map(b => scoperta.decidi(b[0]));
  const secondari = BOT.filter(b => b[2] === 2).map(b => scoperta.decidi(b[0]));

  const conta = (l) => { const c = {}; for (const x of l) if (x) c[x] = (c[x] || 0) + 1; return c; };
  const perLingua = {};
  for (const q of pagine) (perLingua[q.lang || '?'] = perLingua[q.lang || '?'] || []).push(q);
  let doppi = 0;
  for (const g of Object.values(perLingua)) {
    doppi += Object.values(conta(g.map(x => x.titolo))).filter(n => n > 1).length;
    doppi += Object.values(conta(g.map(x => x.descrizione))).filter(n => n > 1).length;
  }

  const indirizzi = pagine.map(p => p.url).join(' ').toLowerCase();
  const c = (...p) => p.some(x => indirizzi.includes(x));

  return Object.assign({}, perPagina, {
    botPrimari: { quota: primari.filter(x => x.ammesso).length / primari.length },
    botSecondari: { quota: secondari.filter(x => x.ammesso).length / secondari.length },
    sitemap: { quota: scoperta.sitemapTrovate ? 1 : 0 },
    llms: { quota: scoperta.llmsPresente ? 1 : 0 },
    quattroZeroQuattro: { quota: scoperta.statoFinto === 404 || scoperta.statoFinto === 410 ? 1 : 0 },
    titoliUnici: { quota: doppi === 0 ? 1 : Math.max(0, 1 - doppi / pagine.length) },
    canonicalCoerente: { quota: perPagina.canonicalCoerente ? perPagina.canonicalCoerente.quota : 1 },
    nap: { quota: 1 },
    paginePolicy: { quota: (c('privacy', 'informativa', 'datenschutz') ? 0.5 : 0)
      + (c('note-legali', 'legal', 'impressum', 'termini', 'cookie') ? 0.5 : 0) },
    paginaContatti: { quota: c('contatt', 'contact', 'kontakt', 'preventivo') ? 1 : 0 },
  });
}

// ---------------------------------------------------------------- resa
function resa(pagine, scoperta, esiti, origine, velocita) {
  const p = [];
  let presi = 0, massimo = 0;
  const gruppi = [], perse = [];

  for (const g of CONTROLLI) {
    let gp = 0, gt = 0;
    for (const v of g.voci) {
      let e = esiti[v.id];
      if (v.id.startsWith('lh')) {
        const mappa = { lhPerformance: 'performance', lhAccessibility: 'accessibility',
          lhBestPractices: 'best-practices', lhSeo: 'seo' };
        const cat = velocita && velocita.disponibile
          ? velocita.categorie.find(c => c.id === mappa[v.id]) : null;
        e = cat ? { quota: cat.punteggio / 100, valore: cat.punteggio + '/100' } : null;
      }
      v._stato = e ? 'misurato' : 'assente';
      v._quota = e ? e.quota : null;
      v._valore = e && e.valore ? e.valore : null;
      v._n = e ? e.n : null; v._tot = e ? e.tot : null;
      if (!e) continue;
      v._punti = Math.round(v.punti * e.quota);
      gp += v._punti; gt += v.punti;
      if (e.quota < 0.999) perse.push({ v, persi: v.punti - v._punti });
    }
    gruppi.push({ nome: g.gruppo, presi: gp, totali: gt });
    presi += gp; massimo += gt;
  }
  const voto = Math.round(presi / massimo * 100);
  const liv = livello(voto / 100);

  const conta = {};
  for (const q of pagine) for (const t of (q.tecnologie || []))
    conta[t.nome + '|' + t.tipo] = (conta[t.nome + '|' + t.tipo] || 0) + 1;
  const SEMPRE = ['piattaforma', 'costruttore', 'negozio', 'server', 'rete'];
  const soglia = Math.max(2, Math.floor(pagine.length * 0.2));
  const tec = Object.entries(conta)
    .map(([k, n]) => { const [nome, tipo] = k.split('|'); return { nome, tipo, n }; })
    .filter(t => SEMPRE.includes(t.tipo) ? t.n >= 1 : t.n >= soglia)
    .sort((a, b) => b.n - a.n);
  const gen = (pagine.find(q => q.generatore) || {}).generatore;
  const piatt = tec.find(t => t.tipo === 'piattaforma');
  const conCosa = piatt ? piatt.nome : (gen ? gen.split(/[-–—(]/)[0].trim() : '');

  p.push('<div class="punteggio"><div class="quadrante liv-' + liv +
    '" style="border-color:var(--' + liv + ')">' + voto + '</div><div>' +
    '<div class="dominio">' + T(origine) + ' · ' + pagine.length + ' pagine lette</div>' +
    (conCosa ? '<p class="conCosa">Il sito è stato creato con <b>' + T(conCosa) + '</b></p>' : '') +
    '<p>' + (voto >= 95 ? 'Il sito è in ottimo stato: quello che manca è rifinitura.'
      : voto >= 80 ? 'Buona base, con qualche punto da sistemare.'
      : voto >= 60 ? 'Ci sono difetti che vale la pena correggere.'
      : 'Il sito ha problemi di fondo.') + '</p></div></div>');

  p.push('<div class="gruppi">');
  for (const g of gruppi) {
    const l = livello(g.totali ? g.presi / g.totali : null);
    p.push('<div><b class="liv-' + l + '">' + g.presi + '</b><span>/' + g.totali + ' ' +
      T(g.nome) + '</span><i><em class="liv-' + l + '" style="width:' +
      (g.totali ? Math.round(g.presi / g.totali * 100) : 0) + '%;background:var(--' + l + ')"></em></i></div>');
  }
  p.push('</div>');

  if (perse.length) {
    perse.sort((a, b) => b.persi - a.persi);
    p.push('<h2>Le tre cose che pesano di più</h2>');
    for (const x of perse.slice(0, 3)) {
      const l = x.persi >= 3 ? 'rosso' : x.persi >= 2 ? 'arancio' : 'giallo';
      const quante = x.v._tot ? ' — ' + (x.v._tot - x.v._n) + ' pagine' : '';
      p.push('<div class="controllo ' + l + '" style="padding:.7rem .85rem"><b>−' + x.persi +
        ' punti</b> ' + T((x.v.no || x.v.nome) + quante) +
        '<div class="nota" style="margin-top:.3rem">' + T(x.v.come) + '</div></div>');
    }
  }

  p.push('<h2>Tutti i controlli, uno per uno</h2>');
  for (const g of CONTROLLI) {
    const gg = gruppi.find(x => x.nome === g.gruppo);
    p.push('<h3 style="font-size:.9rem;margin:1.2rem 0 .5rem">' + T(g.gruppo) +
      ' — ' + gg.presi + ' su ' + gg.totali + '</h3>');
    for (const v of g.voci) {
      const assente = v._stato === 'assente';
      const l = assente ? 'grigio' : livello(v._quota);
      const nome = (!assente && v._quota < 0.5 && v.no) ? v.no : v.nome;
      let et;
      if (assente) et = 'non misurato';
      else if (v._valore) et = v._valore;
      else if (v._quota >= 0.999) et = 'superato';
      else if (v._quota <= 0.001) et = 'non superato';
      else if (v._tot) { const d = v._tot - v._n;
        et = (v._quota < 0.5 && v.no ? 'su ' : 'manca su ') + d + (d === 1 ? ' pagina' : ' pagine'); }
      else et = 'parziale';
      p.push('<details class="controllo ' + l + '"><summary>' +
        '<span class="che liv-' + l + '">' + SEGNI[l] + T(nome) + '</span>' +
        '<span class="pill liv-' + l + '">' + T(et) + '</span>' +
        '<span class="quanti">' + (assente ? '—' : v._punti + '/' + v.punti) + '</span></summary>' +
        '<div class="spiega"><b>Perché conta</b>' + T(v.perche) +
        '<b>Come si sistema</b>' + T(v.come) +
        (v.fonte ? '<b>Fonte</b><a href="' + T(v.fonte.u) + '" target="_blank">' +
          T(v.fonte.n) + '</a>' : '') + '</div></details>');
    }
  }

  if (velocita && velocita.disponibile) {
    p.push('<h2>Velocità misurata</h2><table><tr><th>Metrica</th><th>Valore</th></tr>');
    for (const m of velocita.metriche)
      p.push('<tr><td>' + T(m.nome) + '<div class="nota">' + T(m.spiegazione) +
        '</div></td><td class="num">' + T(m.valore) + '</td></tr>');
    p.push('</table>');
  }

  p.push('<h2>Chi può leggere il sito</h2><table><tr><th>Crawler</th><th>Chi è</th><th>Accesso</th></tr>');
  for (const [nome, chi] of BOT) {
    const d = scoperta.decidi(nome);
    p.push('<tr><td style="font-family:var(--mono);font-size:.78rem">' + T(nome) + '</td><td>' +
      T(chi) + '</td><td class="num liv-' + (d.ammesso ? 'ok' : 'rosso') + '">' +
      (d.ammesso ? 'entra' : 'bloccato') + '</td></tr>');
  }
  p.push('</table>');

  if (tec.length) {
    p.push('<h2>Con cosa è fatto il sito</h2><table><tr><th>Categoria</th><th>Rilevato</th></tr>');
    const ETI = { piattaforma: 'Piattaforma', costruttore: 'Costruttore di pagine',
      negozio: 'Commercio elettronico', server: 'Server', rete: 'Rete di distribuzione',
      libreria: 'Librerie', stili: 'Stili e caratteri', misurazione: 'Misurazione',
      consensi: 'Consensi', contatto: 'Contatto' };
    for (const tipo of Object.keys(ETI)) {
      const gr = tec.filter(t => t.tipo === tipo);
      if (gr.length) p.push('<tr><td>' + T(ETI[tipo]) + '</td><td>' +
        gr.map(t => T(t.nome)).join(' · ') + '</td></tr>');
    }
    p.push('</table>');
  }

  p.push('<h2>Cosa c\'è scritto, pagina per pagina</h2>');
  const ordinate = pagine.slice().sort((a, b) => a.url.localeCompare(b.url));
  const misura = (n, min, max) => n === 0 ? 'rosso' : (n < min || n > max) ? 'giallo' : 'ok';
  for (const q of ordinate) {
    const tl = (q.titolo || '').length, dl = (q.descrizione || '').length;
    p.push('<details class="contenuto"><summary><span class="dove">' +
      T(q.url.replace(origine, '') || '/') + '</span>' +
      '<span class="pill liv-' + misura(tl, 30, 60) + '">title ' + tl + '</span>' +
      '<span class="pill liv-' + misura(dl, 70, 160) + '">descr ' + dl + '</span>' +
      '<span class="pill liv-' + (q.h1 === 1 ? 'ok' : 'rosso') + '">H1 ' + q.h1 + '</span>' +
      '</summary><div class="dentro">');
    p.push('<div class="campo"><b>Titolo per Google</b><span class="testo">' +
      (q.titolo ? T(q.titolo) : '<em>assente</em>') + '</span><span class="misura">' + tl +
      ' caratteri</span></div>');
    p.push('<div class="campo"><b>Descrizione</b><span class="testo">' +
      (q.descrizione ? T(q.descrizione) : '<em>assente</em>') + '</span><span class="misura">' + dl +
      ' caratteri</span></div>');
    if (q.meta) {
      const m = q.meta;
      const righe = [['charset', m.charset], ['lang', m.lang], ['canonical', m.canonical],
        ['robots', m.robots || 'non dichiarato'], ['viewport', m.viewport], ['og:type', m.ogTipo],
        ['og:locale', m.ogLingua], ['twitter:card', m.twitter], ['author', m.autore],
        ['hreflang', (m.lingue || []).join(', ')]].filter(r => r[1]);
      p.push('<div class="campo"><b>Meta tag</b><table class="meta">');
      for (const [k, v] of righe)
        p.push('<tr><td class="chiave">' + T(k) + '</td><td>' + T(v) + '</td></tr>');
      p.push('</table></div>');
    }
    if (q.scaletta && q.scaletta.length) {
      p.push('<div class="campo"><b>Scaletta dei titoli</b><div class="scaletta">');
      let prec = 0;
      for (const t of q.scaletta) {
        const salta = prec && t.l > prec + 1;
        p.push('<div class="riga-h' + (salta ? ' salto' : '') + '" style="padding-left:' +
          ((t.l - 1) * 14) + 'px"><span class="liv">H' + t.l + '</span>' + T(t.t) +
          (salta ? '<span class="avviso">salta un livello</span>' : '') + '</div>');
        prec = t.l;
      }
      p.push('</div></div>');
    }
    if (q.tipiSchema && q.tipiSchema.length)
      p.push('<div class="campo"><b>Dati strutturati</b><span class="testo mono">' +
        q.tipiSchema.map(T).join(' · ') + '</span></div>');
    p.push('<div class="campo"><b>Collegamenti in uscita</b>' +
      (q.domini && q.domini.length ? '<span class="testo mono">' + q.domini.map(T).join(' · ') + '</span>'
        : '<span class="testo"><em>nessuno</em></span>') +
      '<span class="misura">' + q.linkInterni + ' interni, ' + q.linkEsterni + ' esterni</span></div>');
    p.push('</div></details>');
  }

  return p.join('');
}

// ---------------------------------------------------------------- avvio
(async function () {
  const passo = document.getElementById('passo');
  const barra = document.getElementById('barra');
  const esito = document.getElementById('esito');
  const avanzamento = document.getElementById('avanzamento');
  const avanza = (t, q) => { passo.textContent = t; barra.style.width = Math.round(q * 100) + '%'; };

  const origine = new URL(location.href).searchParams.get('sito');
  document.getElementById('dominio').textContent = origine || '';

  try {
    if (!origine) throw new Error('Nessun indirizzo da analizzare.');
    const scoperta = await scopri(origine, avanza);

    // La misura di velocità arriva da Google e ci mette il suo: si avvia subito
    // e si aspetta alla fine, mentre le pagine vengono lette.
    const velocitaPromessa = fetch(API_VELOCITA + encodeURIComponent(origine + '/'))
      .then(r => r.text()).then(t => JSON.parse(t)).catch(() => null);

    const risultati = [];
    let fatte = 0;
    const coda = scoperta.pagine.slice();
    async function lavoratore() {
      while (coda.length) {
        const u = coda.shift();
        const r = await prendi(u, 500000);
        if (r.ok) {
          try { risultati.push(analizzaPagina(r.testo, u, {})); } catch (e) { /* pagina illeggibile */ }
        }
        fatte++;
        avanza('Leggo le pagine… ' + fatte + ' di ' + scoperta.pagine.length,
          0.15 + 0.7 * (fatte / scoperta.pagine.length));
      }
    }
    await Promise.all(Array.from({ length: IN_PARALLELO }, lavoratore));

    if (!risultati.length) throw new Error('Nessuna pagina leggibile.');

    avanza('Aspetto la misura di velocità da Google…', 0.9);
    const velocita = await velocitaPromessa;

    const buone = risultati.filter(r => !r.noindex);
    const esiti = calcola(buone.length ? buone : risultati, scoperta);

    document.getElementById('titolo').textContent = 'Rapporto completo';
    avanzamento.style.display = 'none';
    esito.innerHTML = resa(buone.length ? buone : risultati, scoperta, esiti, origine, velocita);
  } catch (err) {
    document.getElementById('titolo').textContent = 'Analisi non riuscita';
    avanzamento.style.display = 'none';
    esito.innerHTML = '<div class="errore"><b>' + T(err.message) + '</b><br><br>' +
      'Se il sito richiede un accesso, apri prima una sua pagina nel browser: ' +
      'l\'estensione userà la stessa sessione.</div>';
  }
})();
