// Rapporto completo dentro l'estensione.
//
// La differenza con lo strumento sul web non è l'aspetto: è da dove partono le
// richieste. Qui le pagine le scarica il tuo browser, con il tuo indirizzo IP e
// la tua sessione. Quindi funziona sui siti che rifiutano le richieste
// provenienti dai datacenter, e sulle aree riservate a cui hai già accesso.
import { analizzaPagina } from './analisi.js';
import { CONTROLLI } from './controlli.js';

const MAX_URL = 200;
const IN_PARALLELO = 6;
const SITEMAP_PROBABILI = [
  '/sitemap.xml',
  '/sitemap_index.xml',   // Yoast, Rank Math, All in One SEO
  '/wp-sitemap.xml',      // WordPress dal 5.5 in poi
  '/sitemap-index.xml',
  '/sitemap/sitemap-index.xml',
  '/sitemap1.xml',
  '/page-sitemap.xml',
  '/post-sitemap.xml',
];

const API_VELOCITA = 'https://puntowebferrara.com/api/lighthouse?url=';

const T = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const livello = (q) => q == null ? 'grigio'
  : q >= 0.999 ? 'ok' : q >= 0.95 ? 'ok' : q >= 0.75 ? 'giallo' : q >= 0.35 ? 'arancio' : 'rosso';

const SEGNI = { ok: '✓ ', giallo: '! ', arancio: '▲ ', rosso: '✕ ', grigio: '– ' };

// ---------------------------------------------------------------- crawler
// L'identificativo della scheda aperta sul sito, se il pannello ce l'ha passato.
const SCHEDA = (() => {
  const v = new URL(location.href).searchParams.get('scheda');
  return v ? Number(v) : null;
})();

// Scarica dalla scheda del sito: la richiesta parte dal contesto del sito
// stesso, con la sua origine e la sua sessione, quindi è indistinguibile da
// una normale navigazione. È il modo per leggere ciò che vede il browser
// invece di ciò che concede a una pagina di estensione.
async function prendiDaScheda(url, limite) {
  const [esito] = await chrome.scripting.executeScript({
    target: { tabId: SCHEDA },
    func: async (indirizzo, tetto) => {
      try {
        const r = await fetch(indirizzo, { redirect: 'follow', credentials: 'include' });
        let t = '';
        try { t = await r.text(); } catch (e) { t = ''; }
        if (tetto && t.length > tetto) t = t.slice(0, tetto);
        return { ok: r.ok, stato: r.status, testo: t };
      } catch (e) {
        return { ok: false, errore: String(e && e.message || e) };
      }
    },
    args: [url, limite || 500000],
  });
  return esito ? esito.result : { ok: false, errore: 'scheda non raggiungibile' };
}

async function prendiDiretto(url, limite) {
  try {
    const r = await fetch(url, { redirect: 'follow', credentials: 'omit' });
    if (!r.ok) return { ok: false, stato: r.status };
    let t = await r.text();
    if (limite && t.length > limite) t = t.slice(0, limite);
    return { ok: true, stato: r.status, testo: t, intestazioni: r.headers };
  } catch (e) {
    return { ok: false, errore: String(e.message || e) };
  }
}

async function prendi(url, limite) {
  if (SCHEDA) {
    const r = await prendiDaScheda(url, limite);
    // se la scheda è stata chiusa o ha cambiato indirizzo, si ripiega
    if (r && (r.ok || r.stato)) return r;
  }
  return prendiDiretto(url, limite);
}

const BOT = [
  ['GPTBot', 'ChatGPT — addestramento e ricerca', 1], ['OAI-SearchBot', 'ChatGPT — ricerca', 1],
  ['ChatGPT-User', 'ChatGPT — navigazione su richiesta', 1], ['ClaudeBot', 'Claude', 1],
  ['Claude-User', 'Claude — navigazione su richiesta', 1], ['PerplexityBot', 'Perplexity', 1],
  ['Google-Extended', 'Google Gemini e AI Overviews', 2], ['GoogleOther', 'Google — usi sperimentali', 2],
  ['Applebot-Extended', 'Apple Intelligence', 2], ['Amazonbot', 'Amazon', 2],
  ['Bingbot', 'Bing e Copilot', 2], ['CCBot', 'Common Crawl', 2],
  ['Bytespider', 'ByteDance', 2], ['cohere-ai', 'Cohere', 2],
];

function leggiRobots(testo) {
  const blocchi = [];
  let corrente = null;
  for (let riga of (testo || '').split(/\r?\n/)) {
    riga = riga.replace(/#.*$/, '').trim();
    if (!riga) continue;
    const i = riga.indexOf(':');
    if (i < 0) continue;
    const campo = riga.slice(0, i).trim().toLowerCase();
    const valore = riga.slice(i + 1).trim();
    if (campo === 'user-agent') {
      if (!corrente || corrente.regole.length) { corrente = { agenti: [], regole: [] }; blocchi.push(corrente); }
      corrente.agenti.push(valore.toLowerCase());
    } else if (corrente && (campo === 'allow' || campo === 'disallow')) {
      corrente.regole.push({ tipo: campo, percorso: valore });
    }
  }
  return (nome) => {
    const n = nome.toLowerCase();
    let b = blocchi.find(x => x.agenti.includes(n)) || blocchi.find(x => x.agenti.includes('*'));
    if (!b) return { ammesso: true, esplicito: false };
    const vieta = b.regole.some(r => r.tipo === 'disallow' && (r.percorso === '/' || r.percorso === ''));
    const permette = b.regole.some(r => r.tipo === 'allow' && r.percorso === '/');
    return { ammesso: permette || !vieta, esplicito: true };
  };
}

async function scopri(origine, avanza) {
  avanza('Leggo robots.txt e sitemap…', 0.05);
  const robots = await prendi(origine + '/robots.txt', 60000);
  const decidi = leggiRobots(robots.ok ? robots.testo : '');

  const dichiarate = robots.ok
    ? [...robots.testo.matchAll(/^\s*sitemap\s*:\s*(\S+)/gim)].map(m => m[1])
    : [];
  // Le sitemap dichiarate nel robots.txt vengono per prime, ma non sono
  // l'ultima parola: capita che dichiarino un file vuoto o rimasto indietro,
  // mentre quella vera sta all'indirizzo standard del plugin.
  const coda = dichiarate.slice(0, 10)
    .concat(SITEMAP_PROBABILI.map(x => origine + x)
      .filter(x => !dichiarate.includes(x)));
  // Traccia di cosa è stato provato: se l'analisi legge una pagina sola,
  // il rapporto deve dire perché invece di lasciarlo indovinare.
  const tentativi = [];
  const pagine = [];
  const malformati = [];
  const viste = new Set();
  let letti = 0;

  while (coda.length && pagine.length < MAX_URL && letti < 28) {
    const indirizzo = coda.shift();
    const doc = await prendi(indirizzo, 900000);
    letti++;
    if (!doc.ok) {
      tentativi.push({ url: indirizzo, esito: doc.stato ? 'risposta ' + doc.stato : (doc.errore || 'non raggiunta') });
      continue;
    }
    const loc = [...doc.testo.matchAll(/<(?:[a-z0-9]+:)?loc>\s*(?:<!\[CDATA\[)?\s*([^<\]\s]+)\s*(?:\]\]>)?\s*<\/(?:[a-z0-9]+:)?loc>/gi)].map(m => m[1].trim());
    const figlie = /<sitemapindex/i.test(doc.testo);
    tentativi.push({
      url: indirizzo,
      esito: loc.length
        ? (figlie ? loc.length + ' sitemap figlie' : loc.length + ' indirizzi')
        : (/<html/i.test(doc.testo)
            ? 'ha risposto una pagina HTML, non una sitemap'
            : 'nessun indirizzo dentro (' + doc.testo.length + ' caratteri ricevuti) \u2014 ' +
              doc.testo.replace(/\s+/g, ' ').slice(0, 700)),
    });
    if (figlie) {
      // Le sitemap figlie vanno lette PRIMA dei candidati ancora da provare:
      // in fondo alla coda rischiavano di non essere raggiunte, e il tetto le
      // scartava proprio quando la coda era piena di indirizzi da tentare.
      const nuove = loc.filter(u => !viste.has(u));
      for (const u of nuove) viste.add(u);
      coda.unshift(...nuove.slice(0, 15));
      continue;
    }
    for (const u of loc) {
      if (viste.has(u) || pagine.length >= MAX_URL) continue;
      viste.add(u);
      // Un indirizzo malformato nella sitemap non è un errore di rete: è una
      // voce sbagliata scritta dal sito, e va contata come tale.
      let valido = null;
      try {
        const url = new URL(u, origine);
        if (/^https?:$/.test(url.protocol) && url.hostname === new URL(origine).hostname)
          valido = url.href;
      } catch (e) { /* resta nullo */ }
      if (valido) pagine.push(valido);
      else malformati.push(u);
    }
  }
  if (!pagine.length) pagine.push(origine + '/');

  avanza('Controllo come risponde a un indirizzo inesistente…', 0.1);
  let statoFinto = null;
  try {
    const r = await fetch(origine + '/pagina-inesistente-verifica-' + Date.now() + '/', { redirect: 'follow' });
    statoFinto = r.status;
  } catch (e) { /* non blocca */ }

  const llms = await prendi(origine + '/llms.txt', 40000);

  return {
    pagine, decidi, tentativi, malformati,
    sitemapTrovate: dichiarate.length || (pagine.length > 1 ? 1 : 0),
    llmsPresente: llms.ok,
    statoFinto,
    intestazioniHome: null,
  };
}

// Chi ospita il sito.
//
// L'intestazione Server dice il software (nginx, Apache), non l'azienda. I
// nameserver invece dicono quasi sempre chi ospita davvero, e i record MX chi
// gestisce la posta. Si leggono via DNS-over-HTTPS, senza dipendenze.
//
// Limite dichiarato: se il dominio è dietro Cloudflare o un servizio simile,
// i nameserver dicono Cloudflare e l'origine resta nascosta. È il suo mestiere.

const HOSTING = [
  [/aruba/i, 'Aruba'],
  [/register\.it|registerdns/i, 'Register.it'],
  [/netsons/i, 'Netsons'],
  [/serverplan/i, 'Serverplan'],
  [/keliweb/i, 'Keliweb'],
  [/vhosting/i, 'VHosting'],
  [/shellrent/i, 'Shellrent'],
  [/siteground/i, 'SiteGround'],
  [/hostinger/i, 'Hostinger'],
  [/ionos|1and1|1&1/i, 'IONOS'],
  [/ovh/i, 'OVH'],
  [/godaddy|domaincontrol/i, 'GoDaddy'],
  [/bluehost/i, 'Bluehost'],
  [/hetzner/i, 'Hetzner'],
  [/digitalocean/i, 'DigitalOcean'],
  [/awsdns|amazonaws/i, 'Amazon Web Services'],
  [/azure-dns|azurewebsites/i, 'Microsoft Azure'],
  [/googledomains|google\.com|googlehosted/i, 'Google'],
  [/cloudflare/i, 'Cloudflare'],
  [/vercel|vercel-dns/i, 'Vercel'],
  [/netlify|nsone/i, 'Netlify'],
  [/github|fastly/i, 'GitHub Pages o Fastly'],
  [/wixdns|wix/i, 'Wix'],
  [/squarespace/i, 'Squarespace'],
  [/shopify/i, 'Shopify'],
  [/wordpress\.com|wpengine|kinsta|flywheel/i, 'hosting WordPress gestito'],
  [/altervista/i, 'Altervista'],
  [/tophost|tophost\.it/i, 'Tophost'],
];

const POSTA = [
  [/google|googlemail/i, 'Google Workspace'],
  [/outlook|microsoft|office365/i, 'Microsoft 365'],
  [/aruba/i, 'Aruba'],
  [/register\.it/i, 'Register.it'],
  [/zoho/i, 'Zoho'],
  [/protonmail|proton\.me/i, 'Proton'],
  [/mailgun|sendgrid|mailchimp/i, 'servizio di invio massivo'],
];

function riconosci(elenco, testo) {
  for (const [prova, nome] of elenco) if (prova.test(testo)) return nome;
  return null;
}

// Interroga il DNS pubblico di Cloudflare, che risponde in JSON.
async function chiediDns(dominio, tipo) {
  try {
    const r = await fetch('https://cloudflare-dns.com/dns-query?name=' +
      encodeURIComponent(dominio) + '&type=' + tipo,
      { headers: { 'Accept': 'application/dns-json' } });
    if (!r.ok) return [];
    const d = await r.json();
    return (d.Answer || []).map(x => String(x.data || '')).filter(Boolean);
  } catch (e) {
    return [];
  }
}

async function chiHospita(origine) {
  let dominio;
  try { dominio = new URL(origine).hostname.replace(/^www\./, ''); }
  catch (e) { return null; }

  const [ns, mx] = await Promise.all([chiediDns(dominio, 'NS'), chiediDns(dominio, 'MX')]);
  const testoNs = ns.join(' ');
  const nome = riconosci(HOSTING, testoNs);
  const mail = riconosci(POSTA, mx.join(' '));

  return {
    nameserver: ns.slice(0, 4).map(x => x.replace(/\.$/, '')),
    hosting: nome,
    posta: mail,
    // Cloudflare e simili nascondono l'origine: va detto, non taciuto.
    mascherato: /cloudflare|akamai|fastly/i.test(testoNs),
  };
}

// ---------------------------------------------------------------- punteggio
function calcola(pagine, scoperta) {
  const perPagina = {};
  const chiavi = Object.keys(pagine[0].flag);
  for (const k of chiavi) {
    const n = pagine.filter(p => p.flag[k]).length;
    perPagina[k] = { quota: n / pagine.length, n, tot: pagine.length };
  }

  const primari = BOT.filter(b => b[2] === 1).map(b => scoperta.decidi(b[0]));
  const secondari = BOT.filter(b => b[2] === 2).map(b => scoperta.decidi(b[0]));

  const conta = (l) => { const c = {}; for (const x of l) if (x) c[x] = (c[x] || 0) + 1; return c; };
  const perLingua = {};
  for (const q of pagine) (perLingua[q.lang || '?'] = perLingua[q.lang || '?'] || []).push(q);
  let doppi = 0;
  for (const g of Object.values(perLingua)) {
    doppi += Object.values(conta(g.map(x => x.titolo))).filter(n => n > 1).length;
    doppi += Object.values(conta(g.map(x => x.descrizione))).filter(n => n > 1).length;
  }

  const indirizzi = pagine.map(p => p.url).join(' ').toLowerCase();
  const c = (...p) => p.some(x => indirizzi.includes(x));

  return Object.assign({}, perPagina, {
    botPrimari: { quota: primari.filter(x => x.ammesso).length / primari.length },
    botSecondari: { quota: secondari.filter(x => x.ammesso).length / secondari.length },
    sitemap: { quota: scoperta.sitemapTrovate ? 1 : 0 },
    llms: { quota: scoperta.llmsPresente ? 1 : 0 },
    quattroZeroQuattro: { quota: scoperta.statoFinto === 404 || scoperta.statoFinto === 410 ? 1 : 0 },
    titoliUnici: { quota: doppi === 0 ? 1 : Math.max(0, 1 - doppi / pagine.length) },
    canonicalCoerente: { quota: perPagina.canonicalCoerente ? perPagina.canonicalCoerente.quota : 1 },
    nap: { quota: 1 },
    paginePolicy: { quota: (c('privacy', 'informativa', 'datenschutz') ? 0.5 : 0)
      + (c('note-legali', 'legal', 'impressum', 'termini', 'cookie') ? 0.5 : 0) },
    paginaContatti: { quota: c('contatt', 'contact', 'kontakt', 'preventivo') ? 1 : 0 },
  });
}


// Cerchio di completamento accanto al titolo di ogni gruppo.
// Il punteggio è su cento, così i gruppi si confrontano fra loro; accanto
// restano i punti veri, che ricordano quanto ciascuno pesa sul totale.
// Pallino con il conteggio: stessa forma dei cerchi dei gruppi, ma qui il
// numero è una quantità, non un punteggio, quindi l'anello è pieno.
function pallino(quanti, liv) {
  return '<svg class="cerchio-gruppo liv-' + liv + '" width="46" height="46" viewBox="0 0 46 46" ' +
    'role="img" aria-label="' + quanti + ' indirizzi"><circle cx="23" cy="23" r="17" fill="none" ' +
    'stroke="currentColor" stroke-width="4"/><text x="23" y="28" text-anchor="middle" ' +
    'fill="currentColor" style="font-size:' + (quanti > 99 ? '11' : '13') + 'px;font-weight:600">' +
    quanti + '</text></svg>';
}

function cerchioGruppo(presi, totali, nome) {
  if (!totali) return '';
  const q = presi / totali;
  const liv = livello(q);
  const R = 17, C = 2 * Math.PI * R;
  const cento = Math.round(q * 100);
  return '<svg class="cerchio-gruppo liv-' + liv + '" width="46" height="46" viewBox="0 0 46 46" ' +
    'role="img" aria-label="' + T(nome) + ': ' + cento + ' su 100">' +
    '<circle cx="23" cy="23" r="' + R + '" fill="none" stroke="var(--linea)" stroke-width="4"/>' +
    (q > 0 ? '<circle cx="23" cy="23" r="' + R + '" fill="none" stroke="currentColor" stroke-width="4" ' +
      'stroke-linecap="round" stroke-dasharray="' + (C * q).toFixed(1) + ' ' + C.toFixed(1) +
      '" transform="rotate(-90 23 23)"/>' : '') +
    '<text x="23" y="27.5" text-anchor="middle" fill="currentColor" ' +
    'style="font-size:13px;font-weight:600">' + cento + '</text></svg>';
}

// Ragnatela dei punteggi, affiancata ai riquadri dei gruppi.
// I due elementi si dividono il lavoro: il grafico mostra la forma dello
// squilibrio — quale lato del sito cede — i riquadri danno i numeri esatti.
// Insieme stanno in una schermata; uno sotto l'altro ne occupavano due.

const SIGLE = {
  'Accesso dei motori IA': 'Motori IA',
  'Dati strutturati': 'Dati strutturati',
  'Segnali E-E-A-T': 'E-E-A-T',
  'Struttura dei contenuti': 'Struttura',
  'Indicizzazione': 'Indicizzazione',
  'Metadati e condivisione': 'Metadati',
  'Sicurezza e configurazione': 'Sicurezza',
  'Peso della pagina': 'Peso pagina',
  'Velocità misurata': 'Velocità',
};

function ragnatela(gruppi) {
  const validi = gruppi.filter(g => g.totali > 0);
  if (validi.length < 3) return '';

  const L = 500, C = L / 2, R = 138, n = validi.length;
  const ang = (i) => (Math.PI * 2 * i) / n - Math.PI / 2;
  const pt = (i, q) => [C + Math.cos(ang(i)) * R * q, C + Math.sin(ang(i)) * R * q];
  const quote = validi.map(g => g.presi / g.totali);

  const p = ['<svg class="ragnatela" viewBox="0 0 ' + L + ' ' + L + '" role="img" ' +
    'aria-label="Punteggio per gruppo di controlli">'];

  for (const v of [0.25, 0.5, 0.75, 1])
    p.push('<polygon points="' + validi.map((_, i) => pt(i, v).map(x => x.toFixed(1)).join(',')).join(' ') +
      '" fill="none" stroke="var(--linea)"' + (v === 1 ? '' : ' stroke-dasharray="2 4"') + '/>');

  for (let i = 0; i < n; i++) {
    const [x, y] = pt(i, 1);
    p.push('<line x1="' + C + '" y1="' + C + '" x2="' + x.toFixed(1) + '" y2="' + y.toFixed(1) +
      '" stroke="var(--linea)"/>');
  }

  p.push('<polygon points="' +
    validi.map((_, i) => pt(i, Math.max(quote[i], 0.02)).map(x => x.toFixed(1)).join(',')).join(' ') +
    '" fill="var(--verde)" fill-opacity="0.14" stroke="var(--verde)" stroke-width="2.5" ' +
    'stroke-linejoin="round"/>');

  for (let i = 0; i < n; i++) {
    const liv = livello(quote[i]);
    const [x, y] = pt(i, Math.max(quote[i], 0.02));
    p.push('<circle class="liv-' + liv + '" cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) +
      '" r="4.5" fill="currentColor"/>');
    const a = ang(i);
    const lx = C + Math.cos(a) * (R + 26);
    const ly = C + Math.sin(a) * (R + 26) + 4;
    const anc = Math.abs(Math.cos(a)) < 0.3 ? 'middle' : (Math.cos(a) > 0 ? 'start' : 'end');
    p.push('<text x="' + lx.toFixed(1) + '" y="' + ly.toFixed(1) + '" text-anchor="' + anc +
      '" class="et-nome">' + T(SIGLE[validi[i].gruppo] || validi[i].gruppo) + '</text>');
  }

  p.push('</svg>');
  return p.join('');
}


// Un'ancora stabile per ogni gruppo: collega i riquadri in cima alla sezione
// corrispondente più in basso.
function ancora(nome) {
  return 'g-' + String(nome).toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}




// L'elenco delle pagine su cui un controllo non passa, con il valore misurato
// accanto a ciascuna. Fino a cinque righe resta aperto: aprire una tendina per
// leggere tre righe è un clic sprecato. Dalla sesta si chiude, ma l'elenco è
// sempre completo — nessun "e altre N".
function dovManca(v, pagine, radice) {
  if (!v || !v.id || !pagine || !pagine.length) return '';
  const ko = pagine.filter(q => q.flag && q.flag[v.id] === false);
  if (!ko.length) return '';

  const riga = (q) => {
    const misura = q.valori && q.valori[v.id];
    return '<span class="riga-dove"><a href="' + T(q.url) + '" target="_blank" rel="noopener">' +
      T(q.url.replace(radice, '') || '/') + '</a>' +
      (misura ? '<em>' + T(misura) + '</em>' : '') + '</span>';
  };

  const corpo = ko.map(riga).join('');
  const titolo = ko.length === 1 ? 'Dove manca \u2014 1 pagina'
    : 'Dove manca \u2014 ' + ko.length + ' pagine';

  if (ko.length <= 5)
    return '<div class="dove-manca"><b>' + titolo + '</b>' + corpo + '</div>';

  return '<details class="dove-manca chiusa"><summary><b>' + titolo + '</b>' +
    '<span class="apri">mostra l\'elenco</span></summary>' + corpo + '</details>';
}

// Il difetto scritto con i numeri di questo sito, non con una formula.
function difettoConcreto(v, pagine) {
  if (!v.id || !pagine || !pagine.length) return '';
  const ko = pagine.filter(q => q.flag && q.flag[v.id] === false);
  if (!ko.length) return '';
  const misure = ko.map(q => q.valori && q.valori[v.id]).filter(Boolean);
  if (!misure.length) return '';
  // se il valore è lo stesso ovunque lo si dice una volta; altrimenti si dà
  // l'intervallo, che è l'informazione che serve per capire quanto è grave
  const distinti = [...new Set(misure)];
  if (distinti.length === 1)
    return '<p class="difetto"><b>Su questo sito</b>' + T(distinti[0]) + '</p>';
  const numeri = misure.map(x => parseFloat(String(x))).filter(x => !isNaN(x));
  if (numeri.length === misure.length) {
    const min = Math.min(...numeri), max = Math.max(...numeri);
    const unita = String(misure[0]).replace(/^[\d.,]+\s*/, '');
    if (min !== max)
      return '<p class="difetto"><b>Su questo sito</b>da ' + min + ' a ' + max + ' ' + T(unita) + '</p>';
  }
  return '<p class="difetto"><b>Su questo sito</b>' + T(distinti[0]) +
    (distinti.length > 1 ? ' e altri valori' : '') + '</p>';
}

// ---------------------------------------------------------------- resa
function resa(pagine, scoperta, esiti, origine, velocita) {
  const p = [];
  let presi = 0, massimo = 0;
  const gruppi = [], perse = [];

  for (const g of CONTROLLI) {
    let gp = 0, gt = 0;
    for (const v of g.voci) {
      let e = esiti[v.id];
      if (v.id.startsWith('lh')) {
        const mappa = { lhPerformance: 'performance', lhAccessibility: 'accessibility',
          lhBestPractices: 'best-practices', lhSeo: 'seo' };
        const cat = velocita && velocita.disponibile
          ? velocita.categorie.find(c => c.id === mappa[v.id]) : null;
        e = cat ? { quota: cat.punteggio / 100, valore: cat.punteggio + '/100' } : null;
      }
      v._stato = e ? 'misurato' : 'assente';
      v._quota = e ? e.quota : null;
      v._valore = e && e.valore ? e.valore : null;
      v._n = e ? e.n : null; v._tot = e ? e.tot : null;
      if (!e) continue;
      v._punti = Math.round(v.punti * e.quota);
      gp += v._punti; gt += v.punti;
      if (e.quota < 0.999) perse.push({ v, persi: v.punti - v._punti });
    }
    gruppi.push({ nome: g.gruppo, presi: gp, totali: gt });
    presi += gp; massimo += gt;
  }
  const voto = Math.round(presi / massimo * 100);
  const liv = livello(voto / 100);

  const conta = {};
  for (const q of pagine) for (const t of (q.tecnologie || []))
    conta[t.nome + '|' + t.tipo] = (conta[t.nome + '|' + t.tipo] || 0) + 1;
  const SEMPRE = ['piattaforma', 'costruttore', 'negozio', 'server', 'rete'];
  const soglia = Math.max(2, Math.floor(pagine.length * 0.2));
  const tec = Object.entries(conta)
    .map(([k, n]) => { const [nome, tipo] = k.split('|'); return { nome, tipo, n }; })
    .filter(t => SEMPRE.includes(t.tipo) ? t.n >= 1 : t.n >= soglia)
    .sort((a, b) => b.n - a.n);
  const gen = (pagine.find(q => q.generatore) || {}).generatore;
  const piatt = tec.find(t => t.tipo === 'piattaforma');
  const conCosa = piatt ? piatt.nome : (gen ? gen.split(/[-–—(]/)[0].trim() : '');

  p.push('<div class="punteggio"><div class="quadrante liv-' + liv +
    '" style="border-color:var(--' + liv + ')">' + voto + '</div><div>' +
    '<div class="dominio">' + T(origine) + ' · ' + pagine.length + ' pagine lette' +
    (scoperta.tentate && scoperta.tentate > pagine.length
      ? ' su ' + scoperta.tentate + ' indirizzi nella sitemap' : '') + '</div>' +
    (conCosa ? '<p class="conCosa">Il sito è stato creato con <b>' + T(conCosa) + '</b></p>' : '') +
    '<p>' + (voto >= 95 ? 'Il sito è in ottimo stato: quello che manca è rifinitura.'
      : voto >= 80 ? 'Buona base, con qualche punto da sistemare.'
      : voto >= 60 ? 'Ci sono difetti che vale la pena correggere.'
      : 'Il sito ha problemi di fondo.') + '</p></div></div>');

  // Grafico e riquadri affiancati, come nel rapporto sul sito.
  p.push('<div class="testata-gruppi">');
  p.push('<div class="lato-grafico">' +
    ragnatela(gruppi.filter(g => g.totali).map(g => ({ gruppo: g.nome, presi: g.presi, totali: g.totali }))) +
    '</div>');
  p.push('<div class="gruppi">');
  for (const g of gruppi) {
    const l = livello(g.totali ? g.presi / g.totali : null);
    p.push('<a class="riquadro-gruppo" href="#' + ancora(g.nome) + '">' +
      '<b class="liv-' + l + '">' + g.presi +
      '<span style="font-size:.72rem;color:var(--grafite);font-weight:400">/' + g.totali + '</span></b>' +
      '<span>' + T(g.nome) + '</span><i><em class="liv-' + l + '" style="width:' +
      (g.totali ? Math.round(g.presi / g.totali * 100) : 0) + '%;background:var(--' + l + ')"></em></i></a>');
  }
  p.push('</div></div>');

  if (perse.length) {
    perse.sort((a, b) => b.persi - a.persi);
    p.push('<h2>Le tre cose che pesano di più</h2>');
    for (const x of perse.slice(0, 3)) {
      const l = x.persi >= 3 ? 'rosso' : x.persi >= 2 ? 'arancio' : 'giallo';
      const quante = x.v._tot ? ' — ' + (x.v._tot - x.v._n) + ' pagine' : '';
      p.push('<div class="controllo ' + l + '" style="padding:.7rem .85rem"><b>−' + x.persi +
        ' punti</b> ' + T((x.v.no || x.v.nome) + quante) +
        '<div class="nota" style="margin-top:.3rem">' + T(x.v.come) + '</div></div>');
    }
  }

  p.push('<h2>Tutti i controlli, uno per uno</h2>');
  for (const g of CONTROLLI) {
    const gg = gruppi.find(x => x.nome === g.gruppo);
    p.push('<h3 class="titolo-gruppo" id="' + ancora(g.gruppo) + '">' +
      cerchioGruppo(gg.presi, gg.totali, g.gruppo) +
      '<span class="nome">' + T(g.gruppo) + '</span>' +
      '<span class="punti">' + gg.presi + ' punti su ' + gg.totali + '</span></h3>');
    for (const v of g.voci) {
      const assente = v._stato === 'assente';
      const l = assente ? 'grigio' : livello(v._quota);
      const nome = (!assente && v._quota < 0.5 && v.no) ? v.no : v.nome;
      let et;
      if (assente) et = 'non misurato';
      else if (v._valore) et = v._valore;
      else if (v._quota >= 0.999) et = 'superato';
      else if (v._quota <= 0.001) et = 'non superato';
      else if (v._tot) { const d = v._tot - v._n;
        et = (v._quota < 0.5 && v.no ? 'su ' : 'manca su ') + d + (d === 1 ? ' pagina' : ' pagine'); }
      else et = 'parziale';
      p.push('<details class="controllo ' + l + '"><summary>' +
        '<span class="che liv-' + l + '">' + SEGNI[l] + T(nome) + '</span>' +
        '<span class="pill liv-' + l + '">' + T(et) + '</span>' +
        '<span class="quanti">' + (assente ? '—' : v._punti + '/' + v.punti) + '</span></summary>' +
        '<div class="spiega">' +
        difettoConcreto(v, pagine) +
        dovManca(v, pagine, origine) +
        '<b>Come si sistema</b>' + T(v.come) +
        '<b>Perché conta</b>' + T(v.perche) +
        (v.fonte ? '<b>Fonte</b><a href="' + T(v.fonte.u) + '" target="_blank">' +
          T(v.fonte.n) + '</a>' : '') + '</div></details>');
    }
  }

  if (velocita && velocita.disponibile) {
    p.push('<h2>Velocità misurata</h2>');
    if (velocita.categorie && velocita.categorie.length) {
      p.push('<div class="cerchi-velocita">');
      for (const c of velocita.categorie)
        p.push('<div>' + cerchioGruppo(c.punteggio, 100, c.nome) +
          '<span>' + T(c.nome) + '</span></div>');
      p.push('</div>');
    }
    p.push('<table><tr><th>Metrica</th><th>Valore</th></tr>');
    for (const m of velocita.metriche)
      p.push('<tr><td class="metrica"><span class="segno liv-' + livello(m.esito) + '">\u25CF</span>' +
        '<span><b>' + T(m.nome) + '</b><div class="nota">' + T(m.spiegazione) +
        '</div></span></td><td class="num">' + T(m.valore) + '</td></tr>');
    p.push('</table>');
  }

  if (pagine.length < 5 && scoperta.tentativi && scoperta.tentativi.length) {
    p.push('<h2>Come è stata trovata la sitemap</h2>');
    p.push('<p class="nota">Sono state lette poche pagine. Qui sotto c\'è cosa ha risposto ' +
      'ogni indirizzo provato: se nessuno contiene una sitemap valida, il sito non ne ha una ' +
      'raggiungibile — ed è di per sé un difetto da correggere.</p>');
    p.push('<table><tr><th>Indirizzo provato</th><th>Risposta</th></tr>');
    for (const t of scoperta.tentativi)
      p.push('<tr><td style="font-family:var(--mono);font-size:.76rem;word-break:break-all">' +
        T(t.url) + '</td><td>' + T(t.esito) + '</td></tr>');
    p.push('</table>');
  }

  // La sezione va mostrata anche quando non ci sono pagine scartate durante la
  // lettura: gli indirizzi non validi vengono fermati prima, alla validazione,
  // e senza questa condizione sparirebbero dal rapporto.
  const scartate = scoperta.scartate || [];
  const malformati = scoperta.malformati || [];
  if (scartate.length || malformati.length) {
    const perMotivo = {};
    for (const x of scartate) (perMotivo[x.motivo] = perMotivo[x.motivo] || []).push(x.url);
    const quanti = scartate.length + malformati.length;
    const quota = quanti / scoperta.tentate;

    // Una sitemap piena di roba che non è contenuto non è un dettaglio: è il
    // documento con cui il sito dice a Google cosa vale la pena visitare.
    const SPIEGA = {
      'risposta 404': {
        liv: 'rosso',
        che: 'Indirizzi dichiarati nella sitemap che non esistono più.',
        come: 'Sono file cancellati dal sito ma rimasti nell\'elenco. Rigenera la sitemap dal ' +
          'pannello del plugin: se l\'errore resta, la sitemap è stata scritta a mano o è in cache.',
      },
      'non è una pagina HTML': {
        liv: 'arancio',
        che: 'Immagini e allegati dichiarati come se fossero pagine.',
        come: 'WordPress crea una voce per ogni file caricato e i plugin SEO le includono per ' +
          'impostazione predefinita. Nelle impostazioni della sitemap disattiva gli allegati: ' +
          'sono pagine senza contenuto proprio.',
      },
      'contenuto illeggibile': {
        liv: 'giallo',
        che: 'Pagine che rispondono ma il cui codice non si riesce a leggere.',
        come: 'Di solito è una codifica dei caratteri sbagliata o una risposta troncata dal server.',
      },
      'indirizzo non valido': {
        liv: 'rosso',
        che: 'Voci della sitemap che non sono indirizzi validi.',
        come: 'Sono righe scritte male nel file: indirizzi relativi, spazi non codificati, ' +
          'o testo finito dentro un tag loc. Un motore le scarta, ma il file resta segnalato ' +
          'come non conforme. Rigenera la sitemap dal plugin, o correggila se è scritta a mano.',
      },
      'non raggiunta': {
        liv: 'arancio',
        che: 'Indirizzi che non hanno risposto affatto.',
        come: 'Può essere un blocco temporaneo o un server che non regge le richieste ravvicinate.',
      },
    };

    p.push('<h2>La sitemap dichiara indirizzi che non sono pagine</h2>');
    p.push('<div class="voce ' + (quota > 0.5 ? 'rosso' : quota > 0.2 ? 'arancio' : 'giallo') + '">' +
      '<b>' + quanti + ' indirizzi su ' + scoperta.tentate + ' non sono contenuto</b> \u2014 ' +
      'il ' + Math.round(quota * 100) + '% di quello che il sito dichiara a Google. ' +
      'La sitemap è l\'elenco delle pagine che chiedi di visitare: ogni voce inutile consuma ' +
      'passaggi di scansione che sarebbero andati ai contenuti veri.</div>');

    if (malformati.length) perMotivo['indirizzo non valido'] = malformati;

    for (const [motivo, elenco] of Object.entries(perMotivo)) {
      const sp = SPIEGA[motivo] || { liv: 'giallo', che: motivo, come: '' };
      const righe = elenco.map(u =>
        '<span class="riga-dove"><a href="' + T(u) + '" target="_blank" rel="noopener">' +
        T(u.replace(origine, '') || u) + '</a></span>').join('');
      const titolo = elenco.length === 1 ? '1 indirizzo' : elenco.length + ' indirizzi';
      const elencoReso = elenco.length <= 5
        ? '<div class="dove-manca"><b>' + titolo + '</b>' + righe + '</div>'
        : '<details class="dove-manca chiusa"><summary><b>' + titolo + '</b>' +
          '<span class="apri">mostra l\'elenco</span></summary>' + righe + '</details>';
      p.push('<div class="scarto ' + sp.liv + '">' +
        pallino(elenco.length, sp.liv) +
        '<div><b>' + T(sp.che) + '</b>' +
        (sp.come ? '<div class="come-scarti">' + T(sp.come) + '</div>' : '') +
        elencoReso + '</div></div>');
    }
  }

  p.push('<h2>Chi può leggere il sito</h2><table><tr><th>Crawler</th><th>Chi è</th><th>Accesso</th></tr>');
  for (const [nome, chi] of BOT) {
    const d = scoperta.decidi(nome);
    p.push('<tr><td style="font-family:var(--mono);font-size:.78rem">' + T(nome) + '</td><td>' +
      T(chi) + '</td><td class="num liv-' + (d.ammesso ? 'ok' : 'rosso') + '">' +
      (d.ammesso ? 'entra' : 'bloccato') + '</td></tr>');
  }
  p.push('</table>');

  if (tec.length || scoperta.hosting) {
    p.push('<h2>Con cosa è fatto il sito</h2><table><tr><th>Categoria</th><th>Rilevato</th></tr>');

    const h = scoperta.hosting;
    if (h) {
      if (h.hosting)
        p.push('<tr><td>Hosting</td><td>' + T(h.hosting) +
          (h.mascherato ? ' <span class="nota">(l\'origine resta nascosta dietro la rete di distribuzione)</span>' : '') +
          '</td></tr>');
      if (h.nameserver && h.nameserver.length)
        p.push('<tr><td>Nameserver</td><td style="font-family:var(--mono);font-size:.76rem">' +
          h.nameserver.map(T).join('<br>') + '</td></tr>');
      if (h.posta) p.push('<tr><td>Posta elettronica</td><td>' + T(h.posta) + '</td></tr>');
    }

    const statico = pagine.filter(q => q.staticoSemplice).length;
    if (statico > pagine.length * 0.8 && !tec.some(t => t.tipo === 'piattaforma'))
      p.push('<tr><td>Natura del sito</td><td>Pagine HTML senza piattaforma riconoscibile: ' +
        'scritte a mano o generate una volta sola <span class="nota">(deduzione per assenza di indizi)</span></td></tr>');

    const ETI = { piattaforma: 'Piattaforma', costruttore: 'Costruttore di pagine',
      negozio: 'Commercio elettronico', server: 'Server', rete: 'Rete di distribuzione',
      libreria: 'Librerie', stili: 'Stili e caratteri', misurazione: 'Misurazione',
      consensi: 'Consensi', contatto: 'Contatto' };
    for (const tipo of Object.keys(ETI)) {
      const gr = tec.filter(t => t.tipo === tipo);
      if (gr.length) p.push('<tr><td>' + T(ETI[tipo]) + '</td><td>' +
        gr.map(t => T(t.nome)).join(' · ') + '</td></tr>');
    }
    p.push('</table>');
  }

  // ---- tabella riepilogativa: una riga per pagina, ordinate per difetti
  p.push('<h2>Pagina per pagina</h2>');
  const conteggio = (q) => {
    const tot = Object.keys(q.flag || {}).length;
    const ok = Object.values(q.flag || {}).filter(Boolean).length;
    return { tot, ok };
  };
  const perDifetti = pagine.slice().sort((a, b) => conteggio(a).ok - conteggio(b).ok);
  const rigaTab = (q) => {
    const { tot, ok } = conteggio(q);
    return '<tr><td style="font-family:var(--mono);font-size:.76rem;word-break:break-all">' +
      T(q.url.replace(origine, '') || '/') + '</td>' +
      '<td class="num">' + (q.parole || 0) + '</td>' +
      '<td class="num">' + (q.blocchiJsonLd || 0) + '</td>' +
      '<td class="num">' + (q.linkInterni || 0) + '</td>' +
      '<td class="num liv-' + livello(ok / tot) + '" style="font-weight:700">' + ok + '/' + tot + '</td></tr>';
  };
  const intestazione = '<tr><th>Pagina</th><th>Parole</th><th>Schema</th><th>Link</th><th>Controlli</th></tr>';

  p.push('<table>' + intestazione);
  for (const q of perDifetti.slice(0, 10)) p.push(rigaTab(q));
  p.push('</table>');
  p.push('<p class="nota">In cima le pagine con più controlli non superati.</p>');

  // Su un sito grande la tabella intera è un muro che nessuno legge: il resto
  // resta consultabile, ma non occupa lo schermo.
  if (perDifetti.length > 10) {
    p.push('<details class="altre-pagine"><summary>Mostra le altre ' +
      (perDifetti.length - 10) + ' pagine</summary><table>' + intestazione);
    for (const q of perDifetti.slice(10)) p.push(rigaTab(q));
    p.push('</table></details>');
  }

  p.push('<h2>Cosa c\'è scritto, pagina per pagina</h2>');
  const ordinate = pagine.slice().sort((a, b) => a.url.localeCompare(b.url));
  const misura = (n, min, max) => n === 0 ? 'rosso' : (n < min || n > max) ? 'giallo' : 'ok';
  // Prime dieci schede visibili, il resto dietro una tendina: su un sito da
  // duecento pagine l'elenco intero stanca prima di essere utile.
  let contate = 0;
  for (const q of ordinate) {
    if (contate === 10)
      p.push('<details class="altre-schede"><summary>Mostra le altre ' +
        (ordinate.length - 10) + ' pagine</summary>');
    contate++;
    const tl = (q.titolo || '').length, dl = (q.descrizione || '').length;
    p.push('<details class="contenuto"><summary><span class="dove">' +
      T(q.url.replace(origine, '') || '/') + '</span>' +
      '<span class="pill liv-' + misura(tl, 30, 60) + '">title ' + tl + '</span>' +
      '<span class="pill liv-' + misura(dl, 70, 160) + '">descr ' + dl + '</span>' +
      '<span class="pill liv-' + (q.h1 === 1 ? 'ok' : 'rosso') + '">H1 ' + q.h1 + '</span>' +
      '</summary><div class="dentro">');
    p.push('<div class="campo"><b>Titolo per Google</b><span class="testo">' +
      (q.titolo ? T(q.titolo) : '<em>assente</em>') + '</span><span class="misura">' + tl +
      ' caratteri</span></div>');
    p.push('<div class="campo"><b>Descrizione</b><span class="testo">' +
      (q.descrizione ? T(q.descrizione) : '<em>assente</em>') + '</span><span class="misura">' + dl +
      ' caratteri</span></div>');
    if (q.meta) {
      const m = q.meta;
      const righe = [['charset', m.charset], ['lang', m.lang], ['canonical', m.canonical],
        ['robots', m.robots || 'non dichiarato'], ['viewport', m.viewport], ['og:type', m.ogTipo],
        ['og:locale', m.ogLingua], ['twitter:card', m.twitter], ['author', m.autore],
        ['hreflang', (m.lingue || []).join(', ')]].filter(r => r[1]);
      p.push('<div class="campo"><b>Meta tag</b><table class="meta">');
      for (const [k, v] of righe)
        p.push('<tr><td class="chiave">' + T(k) + '</td><td>' + T(v) + '</td></tr>');
      p.push('</table></div>');
    }
    if (q.scaletta && q.scaletta.length) {
      p.push('<div class="campo"><b>Scaletta dei titoli</b><div class="scaletta">');
      let prec = 0;
      for (const t of q.scaletta) {
        const salta = prec && t.l > prec + 1;
        p.push('<div class="riga-h' + (salta ? ' salto' : '') + '" style="padding-left:' +
          ((t.l - 1) * 14) + 'px"><span class="liv">H' + t.l + '</span>' + T(t.t) +
          (salta ? '<span class="avviso">salta un livello</span>' : '') + '</div>');
        prec = t.l;
      }
      p.push('</div></div>');
    }
    if (q.tipiSchema && q.tipiSchema.length)
      p.push('<div class="campo"><b>Dati strutturati</b><span class="testo mono">' +
        q.tipiSchema.map(T).join(' · ') + '</span></div>');
    p.push('<div class="campo"><b>Collegamenti in uscita</b>' +
      (q.domini && q.domini.length ? '<span class="testo mono">' + q.domini.map(T).join(' · ') + '</span>'
        : '<span class="testo"><em>nessuno</em></span>') +
      '<span class="misura">' + q.linkInterni + ' interni, ' + q.linkEsterni + ' esterni</span></div>');
    p.push('</div></details>');
  }
  if (ordinate.length > 10) p.push('</details>');

  return p.join('');
}

// ---------------------------------------------------------------- avvio
(async function () {
  const passo = document.getElementById('passo');
  const barra = document.getElementById('barra');
  const esito = document.getElementById('esito');
  const avanzamento = document.getElementById('avanzamento');
  const avanza = (t, q) => { passo.textContent = t; barra.style.width = Math.round(q * 100) + '%'; };

  const origine = new URL(location.href).searchParams.get('sito');
  document.getElementById('dominio').textContent = origine || '';

  try {
    if (!origine) throw new Error('Nessun indirizzo da analizzare.');
    const scoperta = await scopri(origine, avanza);

    // La misura di velocità arriva da Google e ci mette il suo: si avvia subito
    // e si aspetta alla fine, mentre le pagine vengono lette.
    const hostingPromessa = chiHospita(origine).catch(() => null);
    const velocitaPromessa = fetch(API_VELOCITA + encodeURIComponent(origine + '/'))
      .then(r => r.text()).then(t => JSON.parse(t)).catch(() => null);

    const risultati = [];
    let fatte = 0;
    const coda = scoperta.pagine.slice();
    const scartate = [];
    async function lavoratore() {
      while (coda.length) {
        const u = coda.shift();
        const r = await prendi(u, 500000);
        if (!r.ok) {
          scartate.push({ url: u, motivo: r.stato ? 'risposta ' + r.stato : (r.errore || 'non raggiunta') });
        } else if (!/<html|<!doctype/i.test(r.testo.slice(0, 2000))) {
          // capita con le pagine allegato di WordPress, che reindirizzano al
          // file immagine: non sono pagine e non vanno contate come tali
          scartate.push({ url: u, motivo: 'non è una pagina HTML' });
        } else {
          try { risultati.push(analizzaPagina(r.testo, u, {})); }
          catch (e) { scartate.push({ url: u, motivo: 'contenuto illeggibile' }); }
        }
        fatte++;
        avanza('Leggo le pagine… ' + fatte + ' di ' + scoperta.pagine.length,
          0.15 + 0.7 * (fatte / scoperta.pagine.length));
      }
    }
    await Promise.all(Array.from({ length: IN_PARALLELO }, lavoratore));

    if (!risultati.length) throw new Error('Nessuna pagina leggibile.');

    avanza('Aspetto la misura di velocità da Google…', 0.9);
    const velocita = await velocitaPromessa;
    scoperta.hosting = await hostingPromessa;

    const buone = risultati.filter(r => !r.noindex);
    scoperta.scartate = scartate;
    scoperta.tentate = scoperta.pagine.length + (scoperta.malformati || []).length;
    const esiti = calcola(buone.length ? buone : risultati, scoperta);

    document.getElementById('titolo').textContent = 'Rapporto completo';
    avanzamento.style.display = 'none';
    esito.innerHTML = resa(buone.length ? buone : risultati, scoperta, esiti, origine, velocita);
  } catch (err) {
    document.getElementById('titolo').textContent = 'Analisi non riuscita';
    avanzamento.style.display = 'none';
    esito.innerHTML = '<div class="errore"><b>' + T(err.message) + '</b><br><br>' +
      'Se il sito richiede un accesso, apri prima una sua pagina nel browser: ' +
      'l\'estensione userà la stessa sessione.</div>';
  }
})();
