# Estensione "Verifica sito"

Analizza la pagina aperta nel browser con gli stessi 48 controlli dello
strumento su puntowebferrara.com/verifica. Nessun dato esce dal browser.

## Installazione per uso personale (nessun costo, nessuna approvazione)

1. Apri Chrome e vai su `chrome://extensions`
2. Attiva "Modalità sviluppatore", in alto a destra
3. Clicca "Carica estensione non pacchettizzata"
4. Scegli questa cartella

L'icona compare nella barra. Cliccala su una pagina qualsiasi.

Vale anche per Edge (`edge://extensions`) e Brave. Per Firefox serve una
piccola modifica al manifesto.

## Cosa fa che il tool sul web non può fare

- **Legge il DOM costruito dal browser**, non il codice sorgente: vede anche i
  contenuti aggiunti da JavaScript dopo il caricamento.
- **Funziona sui siti che rifiutano le analisi automatiche**: la richiesta è la
  tua normale navigazione, non una chiamata da datacenter.
- **Funziona su pagine dietro login**, aree riservate e ambienti di prova non
  ancora pubblici.

## Cosa non fa

Guarda una pagina per volta. Sitemap, robots.txt, titoli duplicati, coerenza
degli indirizzi e velocità misurata riguardano il sito intero: per quelli
serve l'analisi completa, e il pulsante in fondo al pannello ci porta.

## File

- `manifest.json` — dichiarazione dell'estensione (Manifest V3)
- `pannello.html` / `pannello.js` — interfaccia e logica
- `analisi.js` — motore di analisi, identico a quello del sito
- `controlli.js` — i 48 controlli con spiegazioni e fonti
- `icone/` — icone 48 e 128 px

`analisi.js` e `controlli.js` sono copie di quelli del sito: quando li
aggiorni là, ricopiali qui, altrimenti i due strumenti divergono.
