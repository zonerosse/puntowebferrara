# Estensione "Verifica sito"

Analizza la pagina aperta nel browser con gli stessi 48 controlli dello
strumento su puntowebferrara.com/verifica. Nessun dato esce dal browser.

## Installazione per uso personale (nessun costo, nessuna approvazione)

1. Apri Chrome e vai su `chrome://extensions`
2. Attiva "Modalità sviluppatore", in alto a destra
3. Clicca "Carica estensione non pacchettizzata"
4. Scegli questa cartella

L'icona compare nella barra. Cliccala su una pagina qualsiasi.

Vale anche per Edge (`edge://extensions`) e Brave. Per Firefox serve una
piccola modifica al manifesto.

## Cosa fa che il tool sul web non può fare

- **Legge il DOM costruito dal browser**, non il codice sorgente: vede anche i
  contenuti aggiunti da JavaScript dopo il caricamento.
- **Funziona sui siti che rifiutano le analisi automatiche**: la richiesta è la
  tua normale navigazione, non una chiamata da datacenter.
- **Funziona su pagine dietro login**, aree riservate e ambienti di prova non
  ancora pubblici.

## Le due modalità

**Pannello** (clic sull'icona): analizza la pagina che hai aperto. Punteggio,
meta tag scritti per esteso, scaletta dei titoli, dati strutturati,
collegamenti in uscita.

**Rapporto completo** (pulsante nel pannello): apre una scheda intera, legge
tutte le pagine della sitemap fino a duecento e produce l'analisi del sito —
tutti i 48 controlli, i crawler dei motori IA, le tecnologie riconosciute,
la velocità misurata da Google e il dettaglio pagina per pagina.

## Cosa non fa

Non misura se il sito viene citato dai modelli generativi oggi: richiede di
interrogarli, e chi lo vende gratis lo sta stimando. Non mostra i link in
entrata: servono indici a pagamento.

## File

- `manifest.json` — dichiarazione dell'estensione (Manifest V3)
- `pannello.html` / `pannello.js` — il pannello su singola pagina
- `rapporto.html` / `rapporto.js` — il rapporto completo del sito
- `analisi.js` — motore di analisi, identico a quello del sito
- `controlli.js` — i 48 controlli con spiegazioni e fonti
- `icone/` — 16, 32, 48, 128 e 512 px

`analisi.js` e `controlli.js` sono copie di quelli del sito: quando li
aggiorni là, ricopiali qui, altrimenti i due strumenti divergono.
