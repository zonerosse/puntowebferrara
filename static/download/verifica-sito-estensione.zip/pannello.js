// Pannello dell'estensione: legge la pagina aperta e la giudica con lo stesso
// motore del sito. La differenza sta in cosa riesce a leggere — vedi sotto.
import { analizzaPagina } from './analisi.js';
import { CONTROLLI } from './controlli.js';

const T = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function livello(q) {
  if (q == null) return 'grigio';
  if (q >= 0.999) return 'ok';
  if (q >= 0.95) return 'ok';
  if (q >= 0.75) return 'giallo';
  if (q >= 0.35) return 'arancio';
  return 'rosso';
}

// I controlli che riguardano l'intero sito qui non si possono misurare: una
// pagina sola non dice nulla su sitemap, robots.txt o pagine duplicate.
const SOLO_SITO = new Set([
  'botPrimari', 'botSecondari', 'sitemap', 'llms', 'nap', 'quattroZeroQuattro',
  'titoliUnici', 'canonicalCoerente', 'paginePolicy', 'paginaContatti',
  'lhPerformance', 'lhAccessibility', 'lhBestPractices', 'lhSeo',
]);

async function leggiPagina() {
  const [scheda] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!scheda || !/^https?:/i.test(scheda.url || '')) return null;

  // Si legge il DOM come il browser lo ha costruito, non il codice sorgente:
  // così si vedono anche i contenuti che il sito aggiunge con JavaScript dopo
  // il caricamento — che è esattamente ciò che l'analisi da server non vede.
  const [esito] = await chrome.scripting.executeScript({
    target: { tabId: scheda.id },
    func: () => ({
      html: document.documentElement.outerHTML,
      url: location.href,
      // marca temporale della risposta, utile per capire se è da cache
      tipo: document.contentType,
    }),
  });
  if (!esito) return null;
  return Object.assign({}, esito.result, { idScheda: scheda.id });
}

function resa(dati) {
  const r = analizzaPagina(dati.html, dati.url, {});
  const esiti = {};
  for (const [k, v] of Object.entries(r.flag)) esiti[k] = v ? 1 : 0;

  let presi = 0, totali = 0;
  const gruppi = [], mancano = [];

  for (const g of CONTROLLI) {
    let gp = 0, gt = 0;
    for (const v of g.voci) {
      if (SOLO_SITO.has(v.id)) continue;
      const q = esiti[v.id];
      if (q == null) continue;
      const p = Math.round(v.punti * q);
      gp += p; gt += v.punti;
      if (q < 1) mancano.push({ v, persi: v.punti - p });
    }
    if (gt) { gruppi.push({ nome: g.gruppo, presi: gp, totali: gt }); presi += gp; totali += gt; }
  }

  const voto = totali ? Math.round(presi / totali * 100) : null;
  const liv = livello(voto / 100);
  const giudizio = voto >= 95 ? 'Questa pagina è a posto.'
    : voto >= 80 ? 'Buona, con qualche punto da sistemare.'
    : voto >= 60 ? 'Ci sono difetti che vale la pena correggere.'
    : 'Questa pagina ha problemi di fondo.';

  const p = [];
  p.push('<div class="voto"><div class="num liv-' + liv + '" style="color:var(--' + liv + ')">' +
    voto + '</div><div class="det"><b>' + T(giudizio) + '</b>' +
    r.parole + ' parole · ' + r.blocchiJsonLd + ' blocchi di dati strutturati · ' +
    Math.round(r.peso / 1024) + ' KB</div></div>');

  // Subito dopo il giudizio: chi ha appena letto com'è messa questa pagina è
  // il momento in cui gli interessa sapere come sono messe le altre.
  p.push('<div class="invito"><p>Questa è una pagina sola. Se vuoi vedere ' +
    'come sono messe <b>tutte le pagine del sito</b> — sitemap, robots.txt, ' +
    'titoli duplicati e velocità misurata — l\'analisi completa le legge una per una.</p>' +
    '<button class="btn" id="completa" type="button">Analizza tutto il sito</button></div>');

  p.push('<div class="gruppi">');
  for (const g of gruppi)
    p.push('<div><b>' + g.presi + '<span style="font-size:.7rem;color:var(--grafite)">/' +
      g.totali + '</span></b>' + T(g.nome) + '</div>');
  p.push('</div>');

  if (mancano.length) {
    mancano.sort((a, b) => b.persi - a.persi);
    p.push('<h2>Cosa manca in questa pagina</h2>');
    for (const m of mancano.slice(0, 12)) {
      const liv2 = m.persi >= 3 ? 'rosso' : m.persi >= 2 ? 'arancio' : 'giallo';
      p.push('<div class="voce ' + liv2 + '"><span class="punti">−' + m.persi + '</span>' +
        '<b>' + T(m.v.no || m.v.nome) + '</b>' +
        '<div class="come">' + T(m.v.come) +
        (m.v.fonte ? '<span class="fonte"><a href="' + T(m.v.fonte.u) +
          '" target="_blank">' + T(m.v.fonte.n) + '</a></span>' : '') + '</div></div>');
    }
  } else {
    p.push('<h2>Cosa manca in questa pagina</h2><div class="voce ok">Niente: tutti i controlli ' +
      'applicabili a una singola pagina sono superati.</div>');
  }

  if (r.tipiSchema && r.tipiSchema.length) {
    p.push('<h2>Dati strutturati dichiarati</h2>');
    for (const t of r.tipiSchema) p.push('<div class="riga"><span>' + T(t) + '</span><span>ok</span></div>');
  }

  if (r.tecnologie && r.tecnologie.length) {
    p.push('<h2>Con cosa è fatta</h2>');
    for (const t of r.tecnologie.slice(0, 10))
      p.push('<div class="riga"><span>' + T(t.nome) + '</span><span>' + T(t.tipo) + '</span></div>');
  }

  p.push('<h2>Numeri della pagina</h2>');
  const numeri = [
    ['Titolo', r.titolo ? r.titolo.length + ' caratteri' : 'assente'],
    ['Descrizione', r.descrizione ? r.descrizione.length + ' caratteri' : 'assente'],
    ['Titoli H1', r.h1],
    ['Collegamenti interni', r.linkInterni],
    ['Fonti esterne citate', r.citazioni],
    ['Immagini senza testo alternativo', r.immaginiSenzaAlt],
  ];
  for (const [k, v] of numeri) p.push('<div class="riga"><span>' + T(k) + '</span><span>' + T(v) + '</span></div>');

  p.push('<div class="voce ok" style="margin-top:12px;font-size:.8rem;color:var(--grafite)">' +
    'Sitemap, robots.txt, pagine duplicate e velocità riguardano il sito intero: ' +
    'si misurano con l\'analisi completa.</div>');

  return p.join('');
}

(async function () {
  const dove = document.getElementById('dove');
  const corpo = document.getElementById('corpo');

  // Il pulsante si collega subito, prima di qualunque analisi: se la pagina
  // non è leggibile deve funzionare lo stesso, perché il rapporto completo
  // scarica le pagine per conto suo e non dipende da quella aperta.
  // Il pulsante nasce insieme al rapporto: lo si collega quando esiste.
  const collegaPulsante = (origine, idScheda) => {
    const b = document.getElementById('completa');
    if (!b) return;
    b.textContent = 'Analizza tutto ' + origine.replace(/^https?:\/\//, '');
    b.addEventListener('click', () => {
      // Si passa anche la scheda del sito: il rapporto la userà per scaricare
      // le pagine, così le richieste partono dal contesto del sito stesso e
      // sono in tutto identiche a quelle di una normale navigazione.
      chrome.tabs.create({
        url: chrome.runtime.getURL('rapporto.html') +
          '?sito=' + encodeURIComponent(origine) + '&scheda=' + idScheda,
      });
      window.close();
    });
  };

  try {
    const dati = await leggiPagina();
    if (!dati) {
      dove.textContent = '—';
      corpo.innerHTML = '<div class="attesa"><b>Qui non c\'è niente da leggere.</b>' +
        'Apri una pagina web e riprova.</div>';
      return;
    }
    dove.textContent = dati.url;
    corpo.innerHTML = resa(dati);
    for (const v of corpo.querySelectorAll('.voce b'))
      v.addEventListener('click', () => v.parentElement.classList.toggle('aperta'));
    collegaPulsante(new URL(dati.url).origin, dati.idScheda);


  } catch (err) {
    corpo.innerHTML = '<div class="attesa"><b>Non riesco a leggere questa pagina.</b>' +
      T(err.message) + '</div>';
  }
})();
